# RabbitMQ

## Inhaltsverzeichnis

1. Was ist RabbitMQ?
2. Warum braucht man das in Microservices?
3. Was bringt das überhaupt?
4. Was braucht man, um loszulegen?
5. Wie funktioniert RabbitMQ?
6. Wie benutzt man das in ASP.NET Core?
7. Kurze Demo
8. Fazit & eure Fragen

---

## 1. Was ist RabbitMQ?

### Was ist RabbitMQ?

Ein Message Broker (wie ein „digitaler Postbote“ für Nachrichten zwischen Programmen).

Speichert Nachrichten in Warteschlangen (Queues) und verteilt sie an Empfänger (Consumer).

![alt text](image-1.png)

### Vorteile

Entkopplung: Sender und Empfänger müssen sich nicht direkt kennen (nur RabbitMQ).

Zuverlässigkeit: Nachrichten werden zwischengespeichert und können auch bei Ausfällen der Empfänger später zugestellt werden.

Lastverteilung: Durch paralleles Verarbeiten von Nachrichten wird die Last effizient verteilt.

Unterstützung von Mustern: Ermöglicht Pub/Sub- oder Punkt-zu-Punkt-Kommunikation.

### Architektur eines Message Brokers

#### Verschiedene Konzepte

Queues: Nachrichten werden in Warteschlangen abgelegt und sequenziell verarbeitet.

Topics: Ermöglicht Publish/Subscribe-Muster, bei dem mehrere Konsumenten Nachrichten empfangen können.

Exchanges: Leiten Nachrichten basierend auf Routing-Regeln an die passenden Queues weiter.

Bindings: Verknüpfen Exchanges mit Queues.

# Warum wird RabbitMQ in Microservices eingesetzt?

### 1. Microservices-Kommunikation

Kern-Anwendungsfall von Message Brokern!
Ziel: Entkopplung von Diensten, Kommunikation läuft asynchron über den Broker.

Bsp. Bestellservice nimmt Bestellungen entgegen und schickt eine Nachricht an RabbitMQ: "Neue Bestellung eingegangen"

### 2. Event-Driven Architektur (EDA)

    Ziel: Systeme reagieren auf Ereignisse (Events), nicht auf direkte Aufrufe. (nicht POLL)

     Bsp. Ein Event "Song geliked" wird an RabbitMQ gesendet.

### 3. Task-Queue-Verarbeitung

    Ziel: Zeitaufwändige Aufgaben im Hintergrund (z.B. Bildverarbeitung, Mails).

    Bsp. Bei Instagram lädt ein User ein Foto hoch:
    Die Web-App sendet eine Nachricht an RabbitMQ: "Bild hochgeladen".

### 4. Datenreplikation

    Ziel: Änderungen in Datenbanken/Ereignisse zuverlässig an andere Systeme verteilen.

    Bsp. Immer wenn in der Hauptdatenbank etwas geändert wird, wird ein Ereignis an RabbitMQ geschickt.

### 5. Skalierung und Lastverteilung (Loadbalancing)

    Ziel: Viele Worker bearbeiten die Aufgaben gemeinsam, der Broker verteilt die Last.

    Bsp. Amazon an Black Friday: Viele Bestellungen kommen gleichzeitig rein. Die Arbeit wird automatisch auf alle verteilt – keine Überlastung, jeder arbeitet einen Teil der Bestellungen ab.

# Vorteile der asynchronen Kommunikation

![alt text](image-2.png)

### 1. Entkopplung

Sender und Empfänger müssen nicht gleichzeitig online oder erreichbar sein.

Beispiel:
Der Bestellservice kann Bestellungen aufnehmen, auch wenn der Versandservice gerade gewartet wird.

![alt text](image-5.png)

![alt text](image-3.png)

### 2. Bessere Skalierbarkeit

Du kannst einfach mehr Empfänger (Consumer/Worker) starten, wenn mehr Nachrichten zu bearbeiten sind.

Beispiel:
Bei vielen Bestellungen werden automatisch mehrere Worker gestartet, die Nachrichten abarbeiten.

### 3. Zuverlässigkeit

Nachrichten gehen nicht verloren.
Sie bleiben im Message Broker, bis sie abgeholt werden.

Beispiel:
Wenn ein Service abstürzt, kann er später die Nachrichten trotzdem noch abholen.

### 4. Geringere Abhängigkeit / Flexibilität

Änderungen an einem Service wirken sich nicht direkt auf andere aus.

Du kannst neue Services hinzufügen, ohne bestehende zu ändern.

Beispiel:
Ein neues Statistiksystem kann die gleichen Nachrichten nutzen, wie andere Services.

### 5. Performance / Geschwindigkeit

Der Sender kann sofort weitermachen, nachdem er die Nachricht abgeschickt hat.

Er muss nicht auf die Antwort warten.

Beispiel:
Ein Webshop zeigt dem Kunden sofort „Bestellung erhalten!“, während im Hintergrund noch geprüft wird, ob das Produkt verfügbar ist.

### 6. Fehlertoleranz

Wenn einzelne Komponenten kurz nicht verfügbar sind, stört das das Gesamtsystem nicht.

Beispiel:
Der Mail-Service ist für 10 Minuten offline – keine Nachricht geht verloren, alle Mails werden später versendet.

# Voraussetzungen für den Einsatz von RabbitMQ in ASP.NET Core:

## Installation von RabbitMQ Docker

#### latest RabbitMQ 4.x

docker run -it --rm --name rabbitmq -p 5672:5672 -p 15672:15672 rabbitmq:4-management

## Installation von RabbitMQ.Client über NuGet

Projekt --> Abhängigkeit --> Nuget Pakete verwalten

![alt text](image-4.png)

## Grundlagen der AMQP (Advanced Message Queuing Protocol)

### Was ist ein AMQP?

AMQP steht für Advanced Message Queuing Protocol.

Es ist ein offener Standard für den Austausch von Nachrichten zwischen Programmen.

### Wichtige Begriffe & Bausteine von AMQP

Producer (Sender):
Schickt Nachrichten ab.

- Beispiel: Dein Bestellservice sendet "Neue Bestellung".

Exchange (Verteiler):
Nimmt Nachrichten vom Producer entgegen.

- Entscheidet (nach Regeln/Routing Keys), in welche Queue die Nachricht kommt.

Queue (Warteschlange):

Speichert Nachrichten zwischen.

- Empfänger (Consumer) holen sich Nachrichten von hier ab.

Consumer (Empfänger):
Holt sich Nachrichten aus einer Queue und verarbeitet sie.

- Beispiel: Versandservice verschickt Pakete, wenn Bestellung ankommt.

Routing Key:

- Ein „Schlüssel“ oder „Tag“, mit dem die Nachricht versehen wird, damit sie zur richtigen Queue geleitet wird.

Binding:

- Die Verbindung zwischen Exchange und Queue, die festlegt, welche Nachrichten in welche Queue geleitet werden.

### Wie läuft das ab? (Einfaches Beispiel)

1. Producer schickt Nachricht mit Routing Key an den Exchange.

2. Der Exchange schaut: Welche Queues interessieren sich für diesen Routing Key? ()

3. Die Nachricht landet in der/den passenden Queue(s).

4. Ein oder mehrere Consumer holen sich die Nachricht aus der Queue ab und verarbeiten sie.

# Kommunikationsarten mit RabbitMQ:

## Einfaches Warteschlangenmodell (Point-to-Point)

Point-to-Point: Eine Queue, ein Empfänger.

## Publish-Subscribe (Fanout Exchange)

Publish-Subscribe: Eine Nachricht, viele Empfänger (über Fanout Exchange).

Beispiel:
Ein Service schickt das Event „Neuer User registriert“ raus.
Alle beteiligten Services (z.B. Statistik, Mail, Logging) bekommen diese Nachricht gleichzeitig.

![alt text](image-6.png)

## Routing (Direct Exchange)

Routing: Nachrichten werden gezielt weitergeleitet, je nach Schlüssel (über Direct Exchange).

Ein Producer schickt eine Nachricht mit einem Routing Key an einen Direct Exchange.
Der Exchange leitet die Nachricht nur an die Queue weiter, deren Binding genau zu diesem Key passt.

# Demo

![alt text](image-10.png)

# Fazit & eure Fragen

RabbitMQ macht es möglich, dass verschiedene Programme oder Microservices sicher, zuverlässig und flexibel miteinander kommunizieren können auch wenn sie nicht gleichzeitig laufen.

![alt text](image-9.png)
